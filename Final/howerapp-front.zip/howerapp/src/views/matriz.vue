
<template>
  <div class="matriz">
       
      <br>

      <div class="textito fadeIn second">
       <b>Perfecto! Terminamos de Clasificar tus tareas según la matriz de Eisen-Hower, selecciona cada cuadrante para visualizar las tareas que contienen.</b>
      </div>
       
       
      <div class="combito">
        
        <div class="img1 card  mb-3 fadeIn second" style="max-width: 18rem;" @click="primercuadrante">
          <div class="right">
              <b-avatar  :text=tareas1 variant="danger"></b-avatar>
          </div>
          
          <h6 class="card-title">URGENTE</h6>
  
  <img  src="https://www.revistahabla.com/wp-content/uploads/2015/07/bomb-3175208_1280.png" alt="">
          <h6 class="card-title">IMPORTANTE</h6>
</div>
        <div class="img2 card  mb-3 fadeIn second" @click="segundocuadrante">
           <div class="right">
           <b-avatar  :text=tareas2 variant="danger"></b-avatar>
           </div>
          <h6 class="card-title">NO URGENTE</h6>
              <img  src="https://www.pikpng.com/pngl/b/330-3307566_horario-icono-png-repeat-visit-icon-clipart.png" alt="">
               <h6 class="card-title">IMPORTANTE</h6>
               
        </div>

         </div>
         
      <div class="combito">
        
        <div class="img3 card  mb-3 fadeIn second" @click="tercercuadrante">
           <div class="right">
            <b-avatar class="right" :text=tareas3 variant="danger"></b-avatar>
          </div>
          <h6 class="card-title">
             
            URGENTE</h6>
          
            <img  src="https://image.flaticon.com/icons/png/512/2753/2753112.png" alt="">
             
             <h6 class="card-title">NO IMPORTANTE
               </h6>
               
            
        </div>

        <div class="img4 card  mb-3 fadeIn second" @click="cuartocuadrante">
           <div class="right">
           <b-avatar  :text=tareas4 variant="danger"></b-avatar>
           </div>
          <h6 class="card-title">NO URGENTE</h6>
            <img  src="https://technodyan.com/wp-content/uploads/2014/07/Shred.png" alt="">
             <h6 class="card-title">NO IMPORTANTE</h6>
        </div>

         </div>
         


  
  </div>
</template>

<script>
import axios from 'axios';

import Vue from 'vue'
import VueCookies from 'vue-cookies'
Vue.use(VueCookies)
Vue.$cookies.config('7d')

export default {
    name:"matriz",
    components: {
    //dragscroll,    

    },
    data:function(){
        return {
            nombre: "",
            tareas1: "",
            tareas2: "",
            tareas3: "",
            tareas4: ""
        }
    
    },
    created(){
    this.iniciar();
    },

    datos:{
        all_data:[]
    },
    methods:{
        iniciar(){
          axios.get('https://howerapp.herokuapp.com/getusers?usr=' + Vue.$cookies.get("usuario"))
          .then(res => {
           
              this.nombre=res.data[0].nombre
              
              //console.log(this.nombre)
          })
        
        axios.post("http://howerapp.herokuapp.com/ntask","username=" + Vue.$cookies.get("usuario"))
          .then(res => {
              if(!res.data.primero)
                  this.tareas1="0";
              else 
                  this.tareas1=res.data.primero;

              if(!res.data.segundo)
                  this.tareas2="0";
              else 
                  this.tareas2=res.data.segundo;

              if(!res.data.tercero)
                  this.tareas3="0";
              else 
                  this.tareas3=res.data.tercero;

              if(!res.data.cuarto)
                  this.tareas4="0";
              else 
                  this.tareas4=res.data.cuarto;                                                    

          })
        },
        primercuadrante(){  
          this.$router.push('primercuadrante');  
        },
        segundocuadrante(){
          this.$router.push('segundocuadrante');  
        },
       tercercuadrante(){
          this.$router.push('tercercuadrante');  
        },
        cuartocuadrante(){
          this.$router.push('cuartocuadrante');  
        }
    }
}
</script>

<style lang="less">
  .right{
    text-align: right;
  }

  .matriz{
      background-color: rgba(240, 237, 220, 0.842);
      align-items: center;
      margin: 0;
    //  background-color: white;
   //background-image: url(https://i.pinimg.com/originals/e2/27/53/e22753cb935f390a3705dd40fe612475.png);
    
    .combito{
      height: 45vh;  
      border: 0;  
      background-color: transparent;
      
      display: flex;
      text-align: center;
       
       .img1{
         
         border-radius: 20px;
        padding: 5px;
color: rgb(255, 255, 255);        
        background-color:#ffb01d;
        //background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAAAA1BMVEWVb9bRd0dIAAAAR0lEQVR4nO3BAQEAAACCIP+vbkhAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO8GxYgAAb0jQ/cAAAAASUVORK5CYII=);
        //align-items: center;
        margin: 15px;
        margin-right: 5px;
        //margin-left: 20px;
        width: 50%;
        //object-fit: cover;
        text-align: center ;
        img{
           text-align: center ;
          margin-left: 2vw;
          margin-top: 2px; 
          margin-bottom: 20px;
          //height: 20vh;          
          width: 18vh;
          border-radius: 5px;
        }
      }    

      .img2{
          border-radius: 20px;
color: rgb(255, 255, 255);       
        background-color:rgb(70, 106, 204);
          // background-image: url(https://i.pinimg.com/originals/d9/7e/dd/d97eddfbccec3e6959dbfea9ec609d29.jpg);

        //align-items: center;
        margin: 15px;
        margin-left: 5px;
        //margin-left: 20px;
        width: 50%;
         text-align: center ;
        //object-fit: cover;
        padding: 5px;
        img{
          
           text-align: center ;
          margin-left: 7vw;
          margin-top: 2vh; 
          margin-bottom: 2vh;
          //height: 20vh;          
          width: 16vh;
          border-radius: 5px;
        }
      }
      .img3{
          border-radius: 20px;
color: rgb(255, 255, 255);      
        background-color:rgb(128, 192, 56);
        
        //align-items: center;
        margin: 15px;
        margin-right: 5px;
        //margin-left: 20px;
        width: 50%;
        padding: 5px;
        //object-fit: cover;
        img{
          
          margin-left: 6vw;
          margin-top: 2vh; 
          margin-bottom: 1vh;
          //height: 20vh;          
          width: 18vh;
          border-radius: 5px;
        }
      }
      .img4{
          border-radius: 20px;
        padding: 5px;
        color: rgb(255, 255, 255);
       
        background-color:#037070;
        //align-items: center;
        margin: 15px;
        margin-left: 5px;
        //margin-left: 20px;
        width: 50%;
        padding: 5px;
        //object-fit: cover;
        img{
          margin-left: 6vw;
          margin-top: 1vh; 
          margin-bottom: 2vh;
          //height: 20vh;          
          width: 18vh;
          border-radius: 5px;
        }
      }
      

      

    }
    .title3{
      text-align: center;
      margin-left: 10px;
      font-weight: 450;
      font-size: 120%;
      color: black;
      height: 15vh;
    }
       
  }
</style>
