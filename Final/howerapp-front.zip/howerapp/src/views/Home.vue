<template>
  <div class="Home">
          <div class="wrapper fadeInDown">
              <div id="formContent">
                <div class="imagen-logo fadeIn first">
                  <img  src="@/assets/logo.png" id="icon" alt="User Icon" />
                </div>

                <!-- Login Form -->
                <form v-on:submit.prevent="login">
                  <input type="text" id="login" class="fadeIn second" name="login" placeholder="Correo" v-model="usuario">                        
                   <b-form-input id="password" class="fadeIn second"  placeholder="Password" type="password" v-model="password"></b-form-input>
                        <div :class="validacion">
                        <i :class="icono"></i>
                        <p> <b>{{ advertencia }}</b></p> 
                        </div> 
                  <input type="submit" class="fadeIn fourth" value="Log In">
                  <button type="button" class="boton-registro fadeIn fourth" v-on:click="registro()" >Registrarse</button>
                </form>

              </div>
            </div>
  </div>
</template>
<script>
import axios from 'axios';
import Vue from 'vue'
import VueCookies from 'vue-cookies'
Vue.config.silent = true;
Vue.use(VueCookies)
Vue.$cookies.config('7d')
export default {
  name: 'about',
  components: {
    
  },
  data: function(){
    return {
      usuario: "",
      password: "",
      advertencia: "",
      icono: "",
      validacion: "",
      error: false,
      error_msg: "Usuario Invalido",
    }
  },
  methods:{
    login(){
        let json = {
          usr : this.usuario,
          pas: this.password
        };
        axios.post('https://howerapp.herokuapp.com/login', "usr="+this.usuario+"&pas="+this.password)
        .then( data =>{
           console.log(json);
           console.log(data);
           if(data.data.msg == "UserIncorrecto"){
             console.log("usuario no es correcto");
             localStorage.token = data.data.result;
             this.validacion="invalido"
             this.advertencia="Usuario Invalido!"
             this.icono="bx bx-sad bx-sm"
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
           }else{
             console.log("usuario correcto");
             this.validacion="valido";
             this.advertencia="Usuario Valido!";
             this.icono="bx bx-happy-heart-eyes bx-sm";
              Vue.$cookies.set('usuario',this.usuario);  
             this.$router.push({
               name: "chatbox"
               });
             
           }
        })
    },
    registro(){
      this.$router.push('registro');  
    }
  }
}
</script>
<style lang="less">


/* BASIC */

html {
  background-color: gainsboro;
}

body {                                                                                                                                                                                                
  font-family: "Poppins", sans-serif;
  height: 100vh;
}

a {
  color: #92badd;
  display:inline-block;
  text-decoration: none;
  font-weight: 450;
}

h2 {
  text-align: center;
  font-size: 16px;
  font-weight: 600;
  text-transform: uppercase;
  display:inline-block;
  margin: 40px 8px 10px 8px; 
  color: #cccccc;
}



/* STRUCTURE */

.wrapper {
  display: flex;
  align-items: center;
  flex-direction: column; 
  justify-content: center;
  width: 100%;
  min-height: 100%;
  padding: 0px;

}




#formContent {
  background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRShZ6oYV7eyYpomTfxlk0BOe7F31hIRHmyGQ&usqp=CAU);
  width: 100%;
  max-width: 450px;
  padding: 40px;
  text-align: center;
  .imagen{
    margin-top: 0;
    padding: 20px;
    
  }
}




/* TABS */

h2.inactive {
  color: #cccccc;
}

h2.active {
  color: #0d0d0d;
  border-bottom: 2px solid #5fbae9;
}



/* FORM TYPOGRAPHY*/



input[type=button], input[type=submit], input[type=reset]  {
  background-color: #56baed;
  border: none;
  color: white;
  padding: 15px;
  width: 100px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-transform: uppercase;
  font-size: 13px;
  -webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
  box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
  -webkit-border-radius: 5px 5px 5px 5px;
  border-radius: 5px 5px 5px 5px;
  margin: 40px 20px 100px 5px;
  -webkit-transition: all 0.3s ease-in-out;
  -moz-transition: all 0.3s ease-in-out;
  -ms-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}
.invalido{
  margin-top: 20px;
  color: red;
}

.valido{
  margin-top: 20px;
  color: green;
}

.imagen-logo{
  align-items: center;
  img{
    
    margin:10px;
    border-radius: 20px;
  }
}

.boton-registro{
  background-color: #037070;
  border: none;
  color: white;
  padding: 15px;
  width: 120px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  text-transform: uppercase;
  font-size: 13px;
  -webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
  box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
  -webkit-border-radius: 5px 5px 5px 5px;
  border-radius: 5px 5px 5px 5px;
  margin: 5px 10px 0px 10px;
  -webkit-transition: all 0.3s ease-in-out;
  -moz-transition: all 0.3s ease-in-out;
  -ms-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

input[type=button]:hover, input[type=submit]:hover, input[type=reset]:hover  {
  background-color: #e7395f;
   padding: 15px;
  width: 100px;
}

input[type=button]:active, input[type=submit]:active, input[type=reset]:active  {
  -moz-transform: scale(0.95);
  -webkit-transform: scale(0.95);
  -o-transform: scale(0.95);
  -ms-transform: scale(0.95);
  transform: scale(0.95);
}

input[type=text]{
  background-color: #f6f6f6;
  border: none;
  color: #0d0d0d;
  padding: 8px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 5px;
  width: 72vw;
  
  border: 0.5px solid #5f5454;
  -webkit-transition: all 0.5s ease-in-out;
  -moz-transition: all 0.5s ease-in-out;
  -ms-transition: all 0.5s ease-in-out;
  -o-transition: all 0.5s ease-in-out;
  transition: all 0.5s ease-in-out;
  -webkit-border-radius: 5px 5px 5px 5px;
  border-radius: 5px 5px 5px 5px;
}

input[type=password]{
  text-align: center;
  background-color: #f6f6f6;
  border: 0.5px solid #5f5454;
  width: 92%;
  //height: 50%;
  margin-left: 10px;
}

input[type=text]:focus {
  background-color: #fff;
  border-bottom: 2px solid #5fbae9;
}

input[type=text]:placeholder {
  color: #cccccc;
}



/* ANIMATIONS */

/* Simple CSS3 Fade-in-down Animation */
.fadeInDown {
  -webkit-animation-name: fadeInDown;
  animation-name: fadeInDown;
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

@-webkit-keyframes fadeInDown {
  0% {
    opacity: 0;
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0);
  }
  100% {
    opacity: 1;
    -webkit-transform: none;
    transform: none;
  }
}

@keyframes fadeInDown {
  0% {
    opacity: 0;
    -webkit-transform: translate3d(0, -100%, 0);
    transform: translate3d(0, -100%, 0);
  }
  100% {
    opacity: 1;
    -webkit-transform: none;
    transform: none;
  }
}

/* Simple CSS3 Fade-in Animation */
@-webkit-keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
@-moz-keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
@keyframes fadeIn { from { opacity:0; } to { opacity:1; } }

.fadeIn {
  margin-top: 10px;
  opacity:0;
  -webkit-animation:fadeIn ease-in 1;
  -moz-animation:fadeIn ease-in 1;
  animation:fadeIn ease-in 1;

  -webkit-animation-fill-mode:forwards;
  -moz-animation-fill-mode:forwards;
  animation-fill-mode:forwards;

  -webkit-animation-duration:1s;
  -moz-animation-duration:1s;
  animation-duration:1s;
}

.fadeIn.first {
  -webkit-animation-delay: 0.4s;
  -moz-animation-delay: 0.4s;
  animation-delay: 0.4s;
}

.fadeIn.second {
  -webkit-animation-delay: 0.6s;
  -moz-animation-delay: 0.6s;
  animation-delay: 0.6s;
}

.fadeIn.third {
  -webkit-animation-delay: 0.8s;
  -moz-animation-delay: 0.8s;
  animation-delay: 0.8s;
}

.fadeIn.fourth {
  -webkit-animation-delay: 1s;
  -moz-animation-delay: 1s;
  animation-delay: 1s;
}
d
/* Simple CSS3 Fade-in Animation */
.underlineHover:after {
  display: block;
  left: 0;
  bottom: -10px;
  width: 0;
  height: 2px;
  background-color: #c0ed56;
  content: "";
  transition: width 0.2s;
}

.underlineHover:hover {
  color: #0d0d0d;
}

.underlineHover:hover:after{
  width: 100%;
}



/* OTHERS */

*:focus {
    outline: none;
} 

#icon {
  width:70%;
}


</style>
