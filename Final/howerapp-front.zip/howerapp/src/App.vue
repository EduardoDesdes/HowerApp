<template>
  <div id="app">
   
    <div class="navbar-container">
      <div class="navbar-content">
        <router-link to="/">
         <i class='bx bxs-user-detail bx-sm'></i>
        </router-link>
        <router-link to="/chatbox">
          <i class='bx bx-message-detail bx-sm'></i>
        </router-link>
        <router-link to="/clasifica">
          <i class='bx bx-task bx-sm'></i>
        </router-link>
        <router-link to="/matriz">
          <i class='bx bx-grid-alt bx-sm' ></i>
        </router-link>
        <router-link to="/about">
          <i class='bx bxs-donate-heart bx-sm'></i>
        </router-link>
      </div>
    </div>
    <router-view />
  </div>
</template>

<script>
export default {
data: () => ({
      prueba: 'hola amigo'
  })
}
</script>

<style lang="less">
@import url('https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Nunito&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Nunito&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Nunito&family=Yanone+Kaffeesatz:wght@300&display=swap');
@import url('https://fonts.googleapis.com/css2?family=DotGothic16&family=Nunito&family=Yanone+Kaffeesatz:wght@300&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Old+Standard+TT:ital@0;1&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Annie+Use+Your+Telescope&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Annie+Use+Your+Telescope&family=Petit+Formal+Script&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Annie+Use+Your+Telescope&family=Belleza&family=Petit+Formal+Script&display=swap');

.navbar-container {
  width: 100%;
  position: flex;
  top: 0;
  background-color: #037070;
  
  .navbar-content {
    border-bottom-color: slategray;
    padding: 13px;
    display: flex;
    justify-content: center;
    a {
      color: rgba(255, 255, 255, 0.438);
      &.router-link-exact-active {
        color: white;
      }
      margin-left: 20px;
      margin-right: 20px;
    }
  }
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
* {
font-family: 'Belleza', sans-serif;
  margin: 0px;
  padding: 0px;
  font-size: 100%;
}
</style>
