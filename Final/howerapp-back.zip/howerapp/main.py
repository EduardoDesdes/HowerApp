from flask import Flask, request, send_file
from flask_restful import Resource, Api
import pymongo
from bson import json_util
import json
from flask_cors import CORS
import re
import io
import csv
from datetime import datetime

client = pymongo.MongoClient("mongodb+srv://admin:1234@cluster0.iofzb.gcp.mongodb.net/testeo1?retryWrites=true&w=majority")
db = client.testeo1
global col
global col1
global col2
col = db.users
col1 = db.proyectos
col2 = db.empresa
col3 = db.tasks


app = Flask(__name__)
CORS(app)
api = Api(app)


class HelloWorld(Resource):
    def get(self):
        return {'v': '0.6'}

class Login(Resource):
    def post(self):
        username=request.form.get('usr')
        password=request.form.get('pas')
        if col.count_documents({"username":username, "password":password}):
            return {'msg': 'UserCorrecto'}
        return {'msg': 'UserIncorrecto'}

class Register(Resource):
    def post(self):
        username=request.form.get('usr')
        password=request.form.get('pas')
        nombre=request.form.get('nombre')
        apellido=request.form.get('apellido')
        if col.count_documents({"username":username}):
            return {'msg': 'El usuario ya existe'}
        elif(col.insert_one({"username":username, "password":password, "nombre":nombre, "apellido":apellido})):
            return {'msg': 'Usuario creado.'}
        return {'msg': 'Error al crear el usuario.'}

# POST
# /addtask
# username=USUARIO&task=Nombre&fecha=11-11-11&hora=11:11&categoria=CATEG
class AddTask(Resource):
    def post(self):
        username=request.form.get('username')
        task=request.form.get('task')
        fecha=request.form.get('fecha')
        hora=request.form.get('hora')
        categoria=request.form.get('categoria')

        if categoria == '':
            categoria = 'Otro'    

        if username is not None and task is not None and fecha is not None and hora is not None and categoria is not None:
            if task == '' or fecha == '':
                return {'msg': 'Es obligatorio ingresar todos los valores'}
            if col3.count_documents({"username":username, "task":task}):
                return {'msg': 'La tarea ya existe para este usuario.'}
            elif(col3.insert_one({"username":username, "task":task, "fecha":fecha, "hora":hora, "categoria":categoria, "clasificacion": "nuevo"})):
                return {'msg': 'Tarea Agregada'}
            return {'msg': 'No se pudo crear la Tarea'}
        else:
            return {'msg': 'Es obligatorio ingresar todos los valores'}

# POST
# /deltask
# username=USUARIO&task=Nombre
class DelTask(Resource):
    def post(self):
        username=request.form.get('username')
        task=request.form.get('task')
        if username is not None and task:
            if task == '':
                return {'msg': 'Es obligatorio ingresar todos los valores'}
            elif (col3.delete_one({"username":username, "task":task})):
                return {'msg': 'Tarea Borrada'}
            return {'msg': 'No se pudo borrar la Tarea'}
        else:
            return {'msg': 'Es obligatorio ingresar todos los valores'}

# POST
# /gettask
# username=USUARIO[&clasificacion={1,2,3,4}]
class GetTask(Resource):
    def post(self):
        username=request.form.get('username')
        clasificacion=request.form.get('clasificacion')

        if username is not None:
            if clasificacion is not None:
                docs_list  = list(col3.find({"username":username, "clasificacion": clasificacion}))
                return json.loads(json.dumps(docs_list, default=json_util.default))
            docs_list  = list(col3.find({"username":username}))
            return json.loads(json.dumps(docs_list, default=json_util.default))
        docs_list  = list(col3.find())
        return json.loads(json.dumps(docs_list, default=json_util.default))

# POST
# /ntask
# username=USUARIO
class ntask(Resource):
    def post(self):
        username=request.form.get('username')

        if username is not None:
                c1  = col3.count_documents(({"username":username, "clasificacion": "1"}))
                c2  = col3.count_documents(({"username":username, "clasificacion": "2"}))
                c3  = col3.count_documents(({"username":username, "clasificacion": "3"}))
                c4  = col3.count_documents(({"username":username, "clasificacion": "4"}))

                return {"primero": c1, "segundo": c2, "tercero": c3, "cuarto": c4}
        return {'msg': 'error'}


# POST
# /clasificar
# username=USUARIO&task=Nombre&clasificacion={1,2,3,4}
class Clasificar(Resource):
    def post(self):
        username=request.form.get('username')
        task=request.form.get('task')
        clasificacion=request.form.get('clasificacion')
        if username is not None and task is not None and clasificacion is not None:
            if username != '' and task != '' and clasificacion != '':
                if col3.count_documents({"username":username,"task":task}):
                    col3.update_one({"username":username,"task":task},{ "$set": { "clasificacion": str(clasificacion)}})
                    return {'msg': 'Tarea Clasificada'}
                else:
                    return {'msg': 'Esa tarea no pertenece al usuario.'}
            return {'msg': 'Es obligatorio ingresar todos los valores'}
        return {'msg': 'Es obligatorio ingresar todos los valores'}
                

# GET
# /temp
class Tmp(Resource):
    def post(self):
        tmp=request.form.get('tmp')
        return { "file": tmp}


# GET
# /downbackup
# ?username=pepito@web.onion
class down_backup(Resource):
    def get(self):
        username=request.args.get('username')

        mem = io.BytesIO()

        if username is not None:
            docs_list  = list(col3.find({"username":username},{"_id": 0, "username": 0}))
            resul = json.dumps(docs_list, default=json_util.default)
            mem.write(resul.encode('utf-8'))
        else:
            resul = "error :c"
            mem.write(resul.encode('utf-8'))

        mem.seek(0)

        return send_file(
            mem,
            as_attachment=True,
            attachment_filename='backup_'+str(datetime.now()).replace(':', '_').replace('-', '_').replace(' ', '_').replace('.', '_')+'.ha',
            mimetype='text'
        )

class getusers(Resource):
    def get(self):
        username=request.args.get('usr')
        if username is not None:
            docs_list  = list(col.find({"username":username}))
            return json.loads(json.dumps(docs_list, default=json_util.default))
        docs_list  = list(col.find())
        return json.loads(json.dumps(docs_list, default=json_util.default))


api.add_resource(HelloWorld, '/')

api.add_resource(Login, '/login')

api.add_resource(Register, '/register')

api.add_resource(AddTask, '/addtask')

api.add_resource(DelTask, '/deltask')

api.add_resource(GetTask, '/gettask')

api.add_resource(Tmp, '/tmp')

api.add_resource(Clasificar, '/clasificar')

api.add_resource(down_backup, '/downbackup')

api.add_resource(getusers, '/getusers')

api.add_resource(ntask, '/ntask')

if __name__ == '__main__':
    app.run(debug=True)
