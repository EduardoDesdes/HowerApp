<template>

<div>
      <b-navbar toggleable="lg" type="dark" variant="info">
          <b-navbar-brand href="#">Vacia tu mente</b-navbar-brand>

      </b-navbar>
        <br><br>
</div>
    
</template>