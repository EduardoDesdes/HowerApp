<template>

        <div>
            <footer>

               Wilfredo aleman 

             </footer>

        </div>

</template>
<style  scoped>
footer {
    position: fixed;
    height: 100px;
    bottom: 0;
    width: 100%;
    background-color: black;
    color: blanchedalmond;
}
</style>