
<template>
    <div>
        <Header />
            <div class="container">
                

                <form action="" class="form-horizontal">
                    <div class="form-group left">
                       <label for="" class="control-label col-sm-2">Tarea</label>
                       <div class="col-sm-10">
                          <input type="text" class="form-control" name="nombre" id="nombre" v-model="form.tarea">
                       </div>
                    </div>
                    <div class="form-group left">
                       <label for="" class="control-label col-sm-2">Fecha</label>
                       <div class="col-sm-10">
                          <input type="text" class="form-control" name="direccion" id="direccion" v-model="form.fecha">
                       </div>
                    </div>
                    <div class="form-group left row">
                      <div class="col">
                        </div>
                        <div class="col">
                          <label for="" class="control-label col-sm-5"></label>
                          <div class="col-sm-7">
                              <button type="button" class="btn btn-primary" v-on:click="guardar()" >Guardar Tarea</button>
                          </div>
                        </div> 
                    </div>
                    <div class="form-group left row">
                         <div class="col">
                            
                          </div>
                         <div class="col">
                              <label for="" class="control-label col-sm-2">Mensaje</label>
                              <div class="col-sm-7">
                                  <input type="text" class="form-control" name="telefono" id="telefono" v-model="form.mensaje">
                              </div>
                        </div>
                    </div>
                    <div class="form-group">
                      <button type="button" class="btn btn-primary" v-on:click="nueva_pagina()" >Finalizar</button>
                      
                    </div> 
                </form>


            </div>
        <!-- <Footer /> -->

    </div>
</template>
<script>
import Header from '@/components/Header.vue'
//import Footer from '@/components/Footer.vue'
import axios from 'axios';
export default {
    name:"Nuevo",
    data:function(){
        return {
            form:{
                tarea: "",
                fecha: ""
            }
        }
    },
    components:{
        Header,
        //Footer
    },
    methods:{
        guardar(){
            this.form.token = localStorage.getItem("token");
            axios.post("http://howerapp.herokuapp.com/addtask","username=pepito@web.onion"+"&task="+this.form.tarea+"&fecha="+this.form.fecha)
            .then(data =>{
            console.log("username=pepito@web.onion"+"&task="+this.form.tarea+"&fecha="+this.form.fecha)
            console.log(data);
            
            if(data.data.msg == "Tarea Agregada"){
                this.form.mensaje="Tarea Agregada"; 
                 console.log("Tarea_agregada");
                 this.form.fecha="";
                 this.form.tarea="";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
            }else{
                this.form.mensaje="Ya existe Tarea! no se agrego";
                console.log("Tarea_no_agregada");
                this.form.fecha="";
                this.form.tarea="";
            }
            })
        },
        nueva_pagina(){
            this.$router.push('Dashboard');  
        },
        makeToast(titulo,texto,tipo) {
            this.toastCount++
            this.$bvToast.toast(texto, {
            title: titulo,
            variant: tipo,
            autoHideDelay: 5000,
            appendToast: true
            })
        }
        
    }
}
</script>
<style scoped>
.left{
    text-align:  left;
}
</style>