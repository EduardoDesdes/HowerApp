<template>
    <div>
        <Header />

            <div class="container">
                
                    <div class="col-sm-10" style="width: 18rem;">
                        
                        </div>
                        

                <form action="" class="form-horizontal">

                    <div class="form-group left row">
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea0" class="fadeIn third" name="form"  v-model="form.tarea0">
                                <p class="card-text"></p>
                                <input type="text" id="fecha0" class="fadeIn third" name="form"  v-model="form.fecha0">
                            </div>
                            </div>
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea1" class="fadeIn third" name="form"  v-model="form.tarea1">
                                <p class="card-text"></p>
                                <input type="text" id="fecha1" class="fadeIn third" name="form"  v-model="form.fecha1">
                            </div>
                            </div>

                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea2" class="fadeIn third" name="form"  v-model="form.tarea2">
                                <p class="card-text"></p>
                                <input type="text" id="fecha2" class="fadeIn third" name="form"  v-model="form.fecha2">
                            </div>
                            </div>

                    </div>

                   <div class="form-group left row">
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea0" class="fadeIn third" name="form"  v-model="form.tarea3">
                                <p class="card-text"></p>
                                <input type="text" id="fecha0" class="fadeIn third" name="form"  v-model="form.fecha3">
                            </div>
                            </div>
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea1" class="fadeIn third" name="form"  v-model="form.tarea4">
                                <p class="card-text"></p>
                                <input type="text" id="fecha1" class="fadeIn third" name="form"  v-model="form.fecha4">
                            </div>
                            </div>

                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea2" class="fadeIn third" name="form"  v-model="form.tarea5">
                                <p class="card-text"></p>
                                <input type="text" id="fecha2" class="fadeIn third" name="form"  v-model="form.fecha5">
                            </div>
                            </div>

                    </div>

                   <div class="form-group left row">
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea0" class="fadeIn third" name="form"  v-model="form.tarea6">
                                <p class="card-text"></p>
                                <input type="text" id="fecha0" class="fadeIn third" name="form"  v-model="form.fecha6">
                            </div>
                            </div>
                        
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea1" class="fadeIn third" name="form"  v-model="form.tarea7">
                                <p class="card-text"></p>
                                <input type="text" id="fecha1" class="fadeIn third" name="form"  v-model="form.fecha7">
                            </div>
                            </div>

                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">Tarea</div>
                            <div class="card-body text-primary">
                                <input type="text" id="tarea2" class="fadeIn third" name="form"  v-model="form.tarea8">
                                <p class="card-text"></p>
                                <input type="text" id="fecha2" class="fadeIn third" name="form"  v-model="form.fecha8">
                            </div>
                            </div>

                    </div>



                    <div class="form-group left row">
                      <div class="col">
                        </div>
                        <div class="col">
                          <label for="" class="control-label col-sm-5"></label>
                          <div class="col-sm-7">
                              <button type="button" class="btn btn-primary" v-on:click="mostrar()" >Mostrar Tareas</button>
                          </div>
                        </div> 
                    </div>

                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                
                            </div>
                        </div>

                    </div>






                        
                              
                        <div class="form-group left row">
                         <div class="col">
                            
                          </div>
                        </div>
                        <div class="form-group">
                        <button type="button" class="btn btn-primary" v-on:click="nueva_pagina()" >Finalizar</button>
                      
                    </div> 
                </form>


            </div>
        <!-- <Footer /> -->

    </div>
</template>
<script>

//import Footer from '@/components/Footer.vue'
import axios from 'axios';
export default {
    name:"Nuevo",
    data:function(){
        return {
            form:{
                tarea0: "",
                fecha0: "",
                tarea1: "",
                fecha1: "",
                tarea2: "",
                fecha2: "",
                tarea3: "",
                fecha3: "",
                tarea4: "",
                fecha4: "",
                tarea5: "",
                fecha5: "",
                tarea6: "",
                fecha6: "",
                tarea7: "",
                fecha7: "",
                tarea8: "",
                fecha8: ""
            }
        }
    
    },

    datos:{
        all_data:[]
    },
    methods:{
        mostrar(){
            this.form.token = localStorage.getItem("token");
            axios.post("http://howerapp.herokuapp.com/gettask","username=pepito@web.onion")
            .then(data =>{
            console.log("username=pepito@web.onion")    
            console.log(data);
               this.all_data=data.data.msg;
               this.form.tarea0=data.data[0].task;
               this.form.fecha0=data.data[0].fecha;    
               this.form.tarea1=data.data[1].task;
               this.form.fecha1=data.data[1].fecha;
               this.form.tarea2=data.data[2].task;
               this.form.fecha2=data.data[2].fecha;
               this.form.tarea3=data.data[3].task;
               this.form.fecha3=data.data[3].fecha;    
               this.form.tarea4=data.data[4].task;
               this.form.fecha4=data.data[4].fecha;
               this.form.tarea5=data.data[5].task;
               this.form.fecha5=data.data[5].fecha;
               this.form.tarea6=data.data[6].task;
               this.form.fecha6=data.data[6].fecha;    
               this.form.tarea7=data.data[7].task;
               this.form.fecha7=data.data[7].fecha;
               this.form.tarea8=data.data[8].task;
               this.form.fecha8=data.data[8].fecha;
            })
        },
        nueva_pagina(){
            this.$router.push("/");
        },
        makeToast(titulo,texto,tipo) {
            this.toastCount++
            this.$bvToast.toast(texto, {
            title: titulo,
            variant: tipo,
            autoHideDelay: 5000,
            appendToast: true
            })
        }
        
    }
}
</script>
<style scoped>
.left{
    text-align:  center;
}
</style>