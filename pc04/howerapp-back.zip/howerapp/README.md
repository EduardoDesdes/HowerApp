# API TELECHAMBA

Site: https://telechambac19.herokuapp.com/

Recursos del aplicativo:

api.add_resource(Login, '/login')
api.add_resource(Register, '/register')
api.add_resource(createproyect, '/createproyect')
api.add_resource(findproyect, '/findproyect')
api.add_resource(getusers, '/getusers')
api.add_resource(getempresas, '/getempresas')
api.add_resource(adminproyectos, '/adminproyectos')
api.add_resource(misproyectos, '/misproyectos')
api.add_resource(createempresa, '/createempresa')
api.add_resource(postular, '/postular')
api.add_resource(contratar, '/contratar')

Esto se pueden usar de la forma:

https://telechambac19.herokuapp.com/adminproyectos?creador=h4x0r@web.onion
https://telechambac19.herokuapp.com/misproyectos?postulante=pcanales@uni.pe
https://telechambac19.herokuapp.com/misproyectos?contratado=filesito@uni.pe
https://telechambac19.herokuapp.com/getusers?usr=filesito@uni.pe
https://telechambac19.herokuapp.com/createempresa?admin=h4x0r@web.onion&nombre=EmpresaFeik&ruc=00000000000&clasificacion=3
https://telechambac19.herokuapp.com/misproyectos?contratado=filesito@uni.pe
https://telechambac19.herokuapp.com/adminproyectos?creador=h4x0r@web.onion
https://telechambac19.herokuapp.com/createproyect?nombre=VamosAJalar&creador=juansito@uni.pe&ruc=4785111592&vacantes=5&descripcion=textogrande&rubro=Rubro1&sueldo=10
https://telechambac19.herokuapp.com/contratar?user=hola@uni.pe&proyecto=Proyecto1
https://telechambac19.herokuapp.com/postular?user=hola@uni.pe&proyecto=Proyecto1
https://telechambac19.herokuapp.com/getempresas
https://telechambac19.herokuapp.com/getempresas?ruc=10101010101



Para levantar la aplicacion en heroku usamos los siguientes comandos:
```
git config core.autocrlf true
git add .
git commit -am "make it better"
git push heroku master
heroku ps:scale web=1
heroku open
```