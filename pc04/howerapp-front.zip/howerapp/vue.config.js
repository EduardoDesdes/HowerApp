module.exports = {
  devServer: {
    disableHostCheck: true
  },

  pluginOptions: {
    moment: {
      locales: [
        ''
      ]
    }
  }
}
